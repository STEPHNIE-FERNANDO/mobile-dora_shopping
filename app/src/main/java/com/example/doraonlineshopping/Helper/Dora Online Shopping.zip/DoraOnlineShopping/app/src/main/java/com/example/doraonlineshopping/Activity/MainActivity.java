package com.example.doraonlineshopping.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.view.Window;

import com.example.doraonlineshopping.Adapter.PopularAdapter;
import com.example.doraonlineshopping.R;
import com.example.doraonlineshopping.databinding.ActivityMainBinding;
import com.example.doraonlineshopping.domain.PopularDomain;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
   ActivityMainBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

statusBarColor();


        initRecyclerView();
    }

    private void statusBarColor() {
        Window window=MainActivity.this.getWindow();
        window.setStatusBarColor(ContextCompat.getColor(MainActivity.this,R.color.pink_dark));
    }

    private void initRecyclerView() {
        ArrayList<PopularDomain> items=new ArrayList<>();
        items.add(new PopularDomain("Moose Black T-Shirt","item_1",4,500,"test"));
        items.add(new PopularDomain("T900 Ultra Smart Watch","item_2",3,800,"gg"));
        items.add(new PopularDomain("iPhone 15 Pro Max","item_3",5,1300,"gg"));

        binding.PopularView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        binding.PopularView.setAdapter(new PopularAdapter(items));
    }
}