package com.example.doraonlineshopping.Helper;

public interface ChangeNumberItemsListener {
    void change();
}
